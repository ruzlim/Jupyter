import nzpy
import pandas as pd
from collections import defaultdict


class MoocArea:
	
	mooc_query = f"""
	SELECT *
	FROM CORPNAPPO.DIM_MOOC_AREA
	WHERE REMARK != 'Dummy' AND ORGID_AA != '0000ZZ'
	"""
	mooc_query_dummy = f"""
	SELECT *
	FROM CORPNAPPO.DIM_MOOC_AREA
	WHERE ORGID_AA != '0000ZZ'
	"""

# query_str = f"""
# SELECT *
# FROM CORPNAPPO.dim_mooc_area_bk20210409
# """

	def __init__(self, conn=None, dummy=False):
		if not conn:
			conn = nzpy.connect(
				user="CORP_CENT", 
				password="password",
				host='10.50.78.21', 
				port=5480, database="TDADEVBAE", 
				securityLevel=1,
				logLevel=0
				)

		if dummy:
			self.mooc_area = pd.read_sql(self.mooc_query_dummy, conn)
		else:
			self.mooc_area = pd.read_sql(self.mooc_query, conn)
			
		# self.mooc_area.columns = [col.decode("utf-8") for col in self.mooc_area.columns]
		self.h_aa = None


	def describe_h(self, h):
		if h not in self.mooc_area['ORGID_H'].unique():
			return ""
		row = self.mooc_area[self.mooc_area['ORGID_H']==h].iloc[0]
		return row['HOP_HINT']

	def describe_aa(self, aa):
		row = self.mooc_area[self.mooc_area['ORGID_AA']==aa].iloc[0]

		output = {
		    'ORGID_H': row['ORGID_H'],
		    'ORGID_R': row['ORGID_R'],
		    'ORGID_G': row['ORGID_G'],
		    'ORGID_P': row['ORGID_P'],
		    'ORG_LEVEL_AA_NAME': row['ORG_LEVEL_AA_NAME'],
		    'PROVINCE_ENG': row['PROVINCE_ENG'],
		    'SUB_DISTRICT_EN': row['SUB_DISTRICT_EN'],
		}

		return output

	def describe_ccaatt(self, ccaatt):
		if ccaatt not in self.mooc_area['CCAATT'].unique():
			return None
		row = self.mooc_area[self.mooc_area['CCAATT']==ccaatt].iloc[0]

		output = {
		    'ORGID_AA': row['ORGID_AA'],
		    'ORGID_H': row['ORGID_H'],
		    'ORGID_R': row['ORGID_R'],
		    'ORGID_G': row['ORGID_G'],
		    'ORGID_P': row['ORGID_P'],
		    'ORG_LEVEL_AA_NAME': row['ORG_LEVEL_AA_NAME'],
		    'PROVINCE_ENG': row['PROVINCE_ENG'],
		    'SUB_DISTRICT_EN': row['SUB_DISTRICT_EN'],
		}

		return output

	def ccaatt_to_all(self):
		ccaatt_to_aa = {}
		ccaatt_to_h = {}
		ccaatt_to_r = {}
		ccaatt_to_g = {}

		for i, row in self.mooc_area.iterrows():
			ccaatt_to_aa[row['CCAATT']] = row['ORGID_AA']
			ccaatt_to_h[row['CCAATT']] = row['ORGID_H']
			ccaatt_to_r[row['CCAATT']] = row['ORGID_R']
			ccaatt_to_g[row['CCAATT']] = row['ORGID_G']

		return ccaatt_to_aa, ccaatt_to_h, ccaatt_to_r, ccaatt_to_g

	def aa_to_h(self):
		return {row['ORGID_AA']: row['ORGID_H'] for _, row in self.mooc_area.iterrows()}

	def aa_to_r(self):
		return {row['ORGID_AA']: row['ORGID_R'] for _, row in self.mooc_area.iterrows()}

	def aa_to_g(self):
		return {row['ORGID_AA']: row['ORGID_G'] for _, row in self.mooc_area.iterrows()}

	def aa_to_all(self):
		aa_to_h = {}
		aa_to_r = {}
		aa_to_g = {}

		for i, row in self.mooc_area.iterrows():
			aa_to_h[row['ORGID_AA']] = row['ORGID_H']
			aa_to_r[row['ORGID_AA']] = row['ORGID_R']    
			aa_to_g[row['ORGID_AA']] = row['ORGID_G']

		return aa_to_h, aa_to_r, aa_to_g

	def h_to_all(self):
		h_to_r = {}
		h_to_g = {}

		for i, row in self.mooc_area.iterrows():
			h_to_r[row['ORGID_H']] = row['ORGID_R']    
			h_to_g[row['ORGID_H']] = row['ORGID_G']

		return h_to_r, h_to_g

	def h_to_aas(self):
		h_to_aa = defaultdict(set)

		for i, row in self.mooc_area.iterrows():
			h_to_aa[row['ORGID_H']].add(row['ORGID_AA'])

		return h_to_aa

	def r_to_hs(self):
	    r_to_h = {}
	    for i, row in self.mooc_area[['ORGID_R', 'ORGID_H']].iterrows():
	        if row['ORGID_R'] not in r_to_h:
	            r_to_h[row['ORGID_R']] = {row['ORGID_H']}
	        else:
	            r_to_h[row['ORGID_R']].add(row['ORGID_H'])
	    return r_to_h

	def g_to_rs(self):
	    g_to_r = {}
	    for i, row in self.mooc_area[['ORGID_R', 'ORGID_G']].iterrows():
	        if row['ORGID_G'] not in g_to_r:
	            g_to_r[row['ORGID_G']] = {row['ORGID_R']}
	        else:
	            g_to_r[row['ORGID_G']].add(row['ORGID_R'])
	    return g_to_r
		

	def missing_aas(self, having_aas):
		output = set(self.mooc_area['ORGID_AA'].unique()).difference(set(having_aas))
		return output

	def h_with_missing_aas(self, having_aas):
	    missing_aas = self.missing_aas(having_aas)
	    aa_h = self.aa_to_h()
	    special_hs = {aa_h[aa] for aa in missing_aas}
	    return special_hs

	def get_missing_and_having_aas_in_h(self, h, having_aas):
		if not self.h_aa:
			self.h_aa = self.h_to_aas()

		having_aas = set(having_aas)
		aas_in_h = set(self.h_aa[h])

		missing_aa_in_h = aas_in_h.difference(having_aas)
		having_aa_in_h = aas_in_h.intersection(having_aas)
		return missing_aa_in_h, having_aa_in_h



