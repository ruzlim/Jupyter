import pandas as pd
import numpy as np
import datetime
from shutil import copyfile
import os
import lnwtrue


def get_stamp_date(year):
    year_all = []
    month_all = []
    day_all = []
    for week_no in range(1,53):
        input_date = f'{year}-W{str(week_no)[-2:]}'
        stamp_date = datetime.datetime.strptime(input_date + '-1', '%G-W%V-%u') + datetime.timedelta(days=6)
        if stamp_date > datetime.datetime(year,12,31):
            stamp_date = datetime.datetime(year,12,31)

        year_all.append(stamp_date.year)
        month_all.append(stamp_date.month)
        day_all.append(stamp_date.day)
    return year_all, month_all, day_all

def get_week_stamp_date(year, week_no):
    input_date = f'{year}-W{str(week_no)[-2:]}'
    stamp_date = datetime.datetime.strptime(input_date + '-1', '%G-W%V-%u') + datetime.timedelta(days=6)
    if stamp_date > datetime.datetime(year,12,31):
        stamp_date = datetime.datetime(year,12,31)
    return stamp_date

def current_week_no():
    return datetime.date.today().isocalendar()[1]

def get_month_from_week(week, year, available_months):
    input_date = f'{year}-W{str(week)[-2:]}'
    stamp_date = datetime.datetime.strptime(input_date + '-1', '%G-W%V-%u') + datetime.timedelta(days=6)

    if stamp_date > datetime.datetime(year,12,31):
        stamp_date = datetime.datetime(year,12,31)

    if stamp_date.day <=3:
        month = stamp_date.month-1 + (year*100)
    else:
        month = stamp_date.month + (year*100)

    max_month = max(available_months)
    if max_month < month:
        month = max_month
    return month


def date_to_week(date):
    start = datetime.datetime.strptime("1-1-2021", "%d-%m-%Y")
    end = datetime.datetime.strptime("10-1-2021", "%d-%m-%Y")
    if start <= date <= end:
        return 1
    else:
        return date.isocalendar()[1]



    
class TrueconnectID:
    
    def __init__(self, refcode_path=None):

        if refcode_path:
            # self.master_data = pd.read_excel(refcode_path, sheet_name='Data ID & Ref Code')
            
            microorg = pd.read_excel(refcode_path, sheet_name='microorg')
            microorg['Org ID'] = microorg['Org ID'].astype(str)
            microorg.loc[microorg['Org Level']=='H', 'Org ID'] = microorg[microorg['Org Level']=='H']['Org ID'].apply(lambda h: h.zfill(3))
            self.microorg = microorg

            self.corporate = pd.read_excel(refcode_path, sheet_name='corporate')
        else:
            sheet_url = 'https://docs.google.com/spreadsheets/d/e/2PACX-1vTZYvIZN6Qy-NNsnqsefryeVmws6cEDQIy0VREmwU0eGLcniSMmJv_2EjrPsjiI1vL-QxUkiILk0XCA/pub?output=xlsx'
            microorg = pd.read_excel(sheet_url, sheet_name='microorg')
            microorg['Org ID'] = microorg['Org ID'].astype(str)
            microorg.loc[microorg['Org Level']=='H', 'Org ID'] = microorg[microorg['Org Level']=='H']['Org ID'].apply(lambda h: h.zfill(3))
            self.microorg = microorg

            self.corporate = pd.read_excel(sheet_url, sheet_name='corporate')
        
    # def code_maps(self, kpi_name):
    #     code_data = self.master_data[self.master_data['KPI'] == kpi_name]
        
    #     dataid_map, refcode_map = {}, {}
    #     for i, row in code_data.iterrows():
    #         dataid_map[row['Org ID']] = str(int(row['Data ID']))
    #         refcode_map[row['Org ID']] = str(row['Ref Code'])
    #     return dataid_map, refcode_map

    def microorg_code(self, kpi_name):
        code_data = self.microorg[self.microorg['KPI'] == kpi_name]
        
        dataid_map, refcode_map = {}, {}
        for i, row in code_data.iterrows():
            if row['Data ID'] == row['Data ID']:
                dataid_map[row['Org ID']] = str(int(row['Data ID']))
                refcode_map[row['Org ID']] = str(row['Ref Code'])
        return dataid_map, refcode_map

    def corporate_code(self, kpi_name):
        code = self.corporate[self.corporate['KPI']==kpi_name]
        corp_code = {'data_id': code['Corporate\nData ID'].iloc[0],
                'ref_code': code['Corporate\nRef Code'].iloc[0]}
        return corp_code
    
    def ref_aas(self):
        return self.master_data.loc[self.master_data['Org Level']=='AA', 'Org ID'].unique()

    def missing_aas_from_ref(self, having_aas):
        return set(self.ref_aas()).difference(having_aas)



class MicroorgActualTemplate:

    def __init__(self, template_path=None):

        if template_path:
            self.template_path = template_path
            self.data = pd.read_excel(template_path, sheet_name='data')
        else:
            TEMPLATE_COLS = ['Data_ID', 'Ref_Code', 'Year', 'Month', 'Date', 'Value', 'Numerator', 
                    'Denominator', 'Remark', 'Issue', 'Solution', 'Support_Needed', 'Delete']

            self.data = pd.DataFrame(columns=TEMPLATE_COLS)


    def save(self, save_path):
        writer = pd.ExcelWriter(save_path, engine='xlsxwriter')
        self.data.to_excel(writer, 'data', index=False)
        writer.save()
        # writer.close()


#     def save(self, save_path):

#         copyfile(self.template_path, save_path)

#         writer = pd.ExcelWriter(save_path, engine='xlsxwriter')
        
#         self.data.to_excel(writer, 'data', index=False)
#         info = pd.read_excel(self.template_path, sheet_name='info')
#         info.to_excel(writer, sheet_name = 'info', index=False)

#         writer.save()
#         writer.close()

        
    def clean_no_id(self):
        self.data.dropna(subset=['Data_ID'], inplace=True)


    @classmethod
    def combine_output(self, input_folder, output_folder):
        all_data = pd.DataFrame()
        for (dirpath, dirnames, filenames) in os.walk(input_folder):
            for file in filenames:
                path = f'{dirpath}/{file}'
                print(path)
                data = pd.read_excel(path, sheet_name='data')
                all_data = all_data.append(data)

        writer = pd.ExcelWriter(output_folder, engine='xlsxwriter')
        all_data.to_excel(writer, 'data', index=False)
        writer.save()
        writer.close()
        print('combine files saved at' + output_folder)

#     @classmethod
#     def combine_output(self, input_folder, output_folder, template_path):
#         all_data = pd.DataFrame()
#         for (dirpath, dirnames, filenames) in os.walk(input_folder):
#             for file in filenames:
#                 path = f'{dirpath}/{file}'
#                 print(path)
#                 data = pd.read_excel(path, sheet_name='data')
#                 all_data = all_data.append(data)

#         copyfile(template_path, output_folder)

#         writer = pd.ExcelWriter(output_folder, engine='xlsxwriter')

#         all_data.to_excel(writer, 'data', index=False)
#         info = pd.read_excel(template_path, sheet_name='info')
#         info.to_excel(writer, sheet_name = 'info', index=False)

#         writer.save()
#         writer.close()
#         print('combine files saved at' + output_folder)





class MicroorgTargetTemplate:
    def __init__(self, template_path):
        self.master_data = pd.read_excel(template_path, sheet_name="KPIs", dtype=str)
        self.geocodes = self.master_data['Geo_Code'].values
        self.truescore = lnwtrue.score
        self.master_data.index = self.master_data['Geo_Code'].values
        
        
    def fill_all_targets_and_scores(self, month_target, is_accum=False, round=False):
        month_target = month_target.loc[self.geocodes]
        target_score = month_target.apply(lambda row: self.truescore.MonthlyScore(np.array(row), is_accum), axis=1)

        # filling annual score
        annual_score = target_score.apply(lambda x: x.annual_score * np.array([0.9, 0.95, 1, 1.05, 1.1]))
        anuual_score_cols = [f'Target_Annual_Score{score}' for score in range(1, 6)]
        self.master_data[anuual_score_cols] = np.array(annual_score.values.tolist())

        # filling quarterly score
        for i, factor in enumerate([0.9, 0.95, 1, 1.05, 1.1]):
            score = i+1
            quarter_score_cols = [f'Target_Quarter{quarter}_Score{score}' for quarter in range(1, 5)]
            quarter_socre = target_score.apply(lambda x: (x.quarterly_scores * factor).tolist())
            self.master_data[quarter_score_cols] = np.array(quarter_socre.values.tolist())

        # filling monthly score
        month_template_cols = [f'Target_Month{month:02}_Target' for month in range(1,13)]
        monthly_score = target_score.apply(lambda x: x.monthly_scores.tolist())
        self.master_data[month_template_cols] = np.array(monthly_score.values.tolist())

        #filling weekly target
        week_targets = target_score.apply(lambda x: x.weekly_scores.tolist())
        week_cols = [f'Target_Week{week:02}_Target' for week in range(1, len(week_targets.values[0])+1)]
        self.master_data[week_cols] = np.array(week_targets.values.tolist())

        #filling weekly score
        for i, factor in enumerate([0.9, 0.95, 1, 1.05, 1.1]):
            score = i+1
            week_score_cols = [f'Target_Week{week:02}_Score{score}' for week in range(1, len(week_targets.values[0])+1)]
            week_socre = target_score.apply(lambda x: (x.weekly_scores * factor).tolist())
            self.master_data[week_score_cols] = np.array(week_socre.values.tolist())

    def fill_annual(self, data_df):
        anuual_score_cols = [f'Target_Annual_Score{score}' for score in range(1, 6)]
        intersec_ids = set(self.master_data.index).intersection(data_df.index)
        self.master_data.loc[intersec_ids, anuual_score_cols] = data_df.loc[intersec_ids].values * [0.9, 0.95, 1, 1.05, 1.1]

    def fill_quarter(self, data_df):
        intersec_ids = set(self.master_data.index).intersection(data_df.index)

        # filling quarterly score
        for i, factor in enumerate([0.9, 0.95, 1, 1.05, 1.1]):
            score = i+1
            quarter_score_cols = [f'Target_Quarter{quarter}_Score{score}' for quarter in range(1, 5)]
            self.master_data.loc[intersec_ids, quarter_score_cols] = data_df.loc[intersec_ids].values * factor

    def fill_month(self, data_df):
        intersec_ids = set(self.master_data.index).intersection(data_df.index)

        # filling monthly score
        month_template_cols = [f'Target_Month{month:02}_Target' for month in range(1,13)]
        self.master_data.loc[intersec_ids, month_template_cols] = data_df.loc[intersec_ids].values
            
    def fill_week(self, data_df):
        intersec_ids = set(self.master_data.index).intersection(data_df.index)

        #filling weekly target
        week_cols = [f'Target_Week{week:02}_Target' for week in range(1, data_df.shape[1]+1)]
        self.master_data.loc[intersec_ids, week_cols] = data_df.loc[intersec_ids].values

        #filling weekly score
        for i, factor in enumerate([0.9, 0.95, 1, 1.05, 1.1]):
            score = i+1
            week_score_cols = [f'Target_Week{week:02}_Score{score}' for week in range(1, data_df.shape[1]+1)]
            self.master_data.loc[intersec_ids, week_score_cols] = data_df.loc[intersec_ids].values * factor

        
        
    def fill_meta(self, meta_series):
        for i in meta_series.index:
            if i in self.master_data.columns:
                self.master_data[i] = meta_series[i]
        
    def fill_weight(self, quarter_weights):

        self.master_data['Weight_Annual'] = quarter_weights[3]
        for q in range(1,5):
            self.master_data[f'Weight_Quarter{q}'] = quarter_weights[q-1]
        for month in range(1,13):
            q = (month-1)//3+1
            self.master_data[f'Weight_Month{month:02}'] = quarter_weights[q-1]

        # Week
        q1_weight_cols = [f'Weight_Week{week:02}' for week in range(1,13)]
        q2_weight_cols = [f'Weight_Week{week:02}' for week in range(13,26)]
        q3_weight_cols = [f'Weight_Week{week:02}' for week in range(26,40)]
        q4_weight_cols = [f'Weight_Week{week:02}' for week in range(40,53)]
        
        self.master_data[q1_weight_cols] = quarter_weights[0]
        self.master_data[q2_weight_cols] = quarter_weights[1]
        self.master_data[q3_weight_cols] = quarter_weights[2]
        self.master_data[q4_weight_cols] = quarter_weights[3]

    def fill_refcode_dataid(self, kpi_name, trueid=None):
        if trueid:
            trueid = trueid
        else:
            trueid = TrueconnectID()

        dataid_map, refcode_map = trueid.microorg_code(kpi_name)
        self.master_data['Data_ID'] = self.master_data['Geo_Code'].map(dataid_map)
        self.master_data['Ref_Code'] = self.master_data['Geo_Code'].map(refcode_map)
        
    def fill_monthly_baseline(self, monthly_baseline=None):
        month_bl_cols = [f'Target_Month{month:02}_Baseline' for month in range(1,13)]

        if monthly_baseline is not None:
            monthly_baseline = monthly_baseline.loc[self.geocodes]
            self.master_data[month_bl_cols] = monthly_baseline.values
        else:
            self.master_data[month_bl_cols] = 0

    def fill_weekly_baseline(self, weekly_baseline=None):
        weel_bl_cols = [f'Target_Week{week:02}_Baseline' for week in range(1,54)]

        if weekly_baseline is not None:
            weekly_baseline = weekly_baseline.loc[self.geocodes]
            self.master_data[weel_bl_cols] = weekly_baseline.values
        else:
            self.master_data[weel_bl_cols] = 0

        
    def save(self, save_path):
        writer = pd.ExcelWriter(save_path, engine='xlsxwriter')
        self.master_data.to_excel(writer, 'KPIs', index=False)
        writer.save()
        # writer.close()

    @classmethod
    def generate_template(cls, kpi_name, month_target, meta_series, year, template_path, month_ly_actual=None, 
                          week_ly_actual=None, trueid=None, is_accum=False):
        
        # template = MicroorgTargetTemplate(template_path)
        template = cls(template_path)
        
        template.master_data = pd.read_excel(template_path, sheet_name="KPIs", dtype=str)
        
        template.fill_all_targets_and_scores(month_target, is_accum)
        template.fill_meta(meta_series)
        template.fill_weight([meta_series['Weight_Quarter1'], meta_series['Weight_Quarter2'], 
            meta_series['Weight_Quarter3'], meta_series['Weight_Quarter4']])
        
        template.fill_refcode_dataid(kpi_name, trueid)
        template.master_data['Year'] = year
        
        # if month_ly_actual:
        template.fill_monthly_baseline(month_ly_actual)
        # if week_ly_actual:
        template.fill_weekly_baseline(week_ly_actual)
        
        return template



class KPITemplateGenerator():

    def __init__(self, kpi_name, trueid=None):
        if trueid:
            self.trueid = trueid
        else:
            self.trueid = TrueconnectID()

        self.dataid_map, self.refcode_map = self.trueid.microorg_code(kpi_name)
        self.corp_code = self.trueid.corporate_code(kpi_name)

    def gen_weekly_microorg(self, data_serie, year, week_no, numer=None, deno=None, fill_missing=False):

        if fill_missing:
            missing_ids = set(self.dataid_map.keys()).difference(data_serie.index)
            for orgid in missing_ids:
                data_serie[orgid] = 0

            if numer:
                numer = numer + ([0] * len(missing_ids))
            if deno:
                deno = deno + ([0] * len(missing_ids))

        template = MicroorgActualTemplate()

        template.data['Value'] = data_serie.values
        template.data['ORG_ID'] = data_serie.index

        if numer is not None:
            template.data['Numerator'] = numer
        if deno is not None:
            template.data['Denominator'] = deno
        
        
        template.data['Data_ID'] = data_serie.index.map(self.dataid_map)
        template.data['Ref_Code'] = data_serie.index.map(self.refcode_map)

        ## Append corp kpi data
        if 'PC' in data_serie.index:
            template.data.loc[template.data['ORG_ID']=='PC', 'Data_ID'] = self.corp_code['data_id']
            template.data.loc[template.data['ORG_ID']=='PC', 'Ref_Code'] = self.corp_code['ref_code']
        else:
            p_value = data_serie['P']
            p_data = {'Data_ID': self.corp_code['data_id'], 
                      'Ref_Code': self.corp_code['ref_code'], 
                      'Value': p_value}
            template.data = template.data.append(p_data, ignore_index=True)

        stamp_date = get_week_stamp_date(year, week_no)
        template.data['Year'] = stamp_date.year
        template.data['Month'] = stamp_date.month
        template.data['Date'] = stamp_date.day

        return template

    def gen_corporate(self, data_array, year):

        template = MicroorgActualTemplate()

        template.data['Value'] = data_array
        
        template.data['Data_ID'] = self.corp_code['data_id']
        template.data['Ref_Code'] = self.corp_code['ref_code']

        year_all, month_all, day_all = get_stamp_date(year)
        template.data['Year'] = year_all[:len(data_array)]
        template.data['Month'] = month_all[:len(data_array)]
        template.data['Date'] = day_all[:len(data_array)]

        return template



class CorporateTargetTemplate:
    def __init__(self, template_path):
        self.master_data = pd.read_csv(template_path, dtype=str)
        
    def fill_weights(self, weights):
        week_rows = {
            1: [f'Weight_Week{week:02}' for week in range(1,13)],
            2: [f'Weight_Week{week:02}' for week in range(13,26)],
            3: [f'Weight_Week{week:02}' for week in range(26,40)],
            4: [f'Weight_Week{week:02}' for week in range(40,53)],
        }
        
        self.master_data.loc[self.master_data['Field']=='Weight_Annual', 'Data'] = weights[-1]
        
        for q in range(1,5):
            self.master_data.loc[self.master_data['Field']==f'Weight_Quarter{q}', 'Data'] = weights[q-1]
            
            start_month = (q-1)*3+1
            end_month = q*3
            month_rows = [f'Weight_Month{month:02}' for month in range(start_month,end_month+1)]
            self.master_data.loc[self.master_data['Field'].isin(month_rows), 'Data'] = weights[q-1]
            
            self.master_data.loc[self.master_data['Field'].isin(week_rows[q]), 'Data'] = weights[q-1]
        
    def fill_annual_scores(self, annual_target):
        self.master_data.loc[self.master_data['Field']=='Target_Annual_Score1', 'Data'] = annual_target * 0.9
        self.master_data.loc[self.master_data['Field']=='Target_Annual_Score2', 'Data'] = annual_target * 0.95
        self.master_data.loc[self.master_data['Field']=='Target_Annual_Score3', 'Data'] = annual_target
        self.master_data.loc[self.master_data['Field']=='Target_Annual_Score4', 'Data'] = annual_target * 1.05
        self.master_data.loc[self.master_data['Field']=='Target_Annual_Score5', 'Data'] = annual_target * 1.1
        
    def fill_quarter_scores(self, q_data):
        q_data = np.array(q_data)

        quarter_rows = [f'Target_Quarter{q}_Score1' for q in range(1,5)]
        self.master_data.loc[self.master_data['Field'].isin(quarter_rows), 'Data'] = q_data * 0.9

        quarter_rows = [f'Target_Quarter{q}_Score2' for q in range(1,5)]
        self.master_data.loc[self.master_data['Field'].isin(quarter_rows), 'Data'] = q_data * 0.95

        quarter_rows = [f'Target_Quarter{q}_Score3' for q in range(1,5)]
        self.master_data.loc[self.master_data['Field'].isin(quarter_rows), 'Data'] = q_data

        quarter_rows = [f'Target_Quarter{q}_Score4' for q in range(1,5)]
        self.master_data.loc[self.master_data['Field'].isin(quarter_rows), 'Data'] = q_data * 1.05

        quarter_rows = [f'Target_Quarter{q}_Score5' for q in range(1,5)]
        self.master_data.loc[self.master_data['Field'].isin(quarter_rows), 'Data'] = q_data * 1.1
        
    def fill_month_scores(self, month_target):
        month_rows = [f'Target_Month{month:02}_Target' for month in range(1,13)]
        self.master_data.loc[self.master_data['Field'].isin(month_rows), 'Data'] = np.array(month_target)
        
    def fill_week_scores(self, week_data):
        week_rows = [f'Target_Week{week:02}_Target' for week in range(1,len(week_data)+1)]
        self.master_data.loc[self.master_data['Field'].isin(week_rows), 'Data'] = np.array(week_data)
        
    # def fill_month_baseline_scores(self, month_target):
    #     month_rows = [f'Target_Month{month:02}_Baseline' for month in range(1,13)]
    #     self.master_data.loc[self.master_data['Field'].isin(month_rows), 'Data'] = np.array(month_target)
        
    # def fill_week_baseline_scores(self, week_data):
    #     week_rows = [f'Target_Week{week:02}_Baseline' for week in range(1,len(week_data)+1)]
    #     self.master_data.loc[self.master_data['Field'].isin(week_rows), 'Data'] = np.array(week_data)
        
    def fill_month_baseline_scores(self, month_target=None):
        month_rows = [f'Target_Month{month:02}_Baseline' for month in range(1,13)]
        
        if month_target is not None:
            self.master_data.loc[self.master_data['Field'].isin(month_rows), 'Data'] = np.array(month_target)
        else:
            self.master_data.loc[self.master_data['Field'].isin(month_rows), 'Data'] = 0
        
    def fill_week_baseline_scores(self, week_data=None):
        
        if week_data is not None:
            week_rows = [f'Target_Week{week:02}_Baseline' for week in range(1,len(week_data)+1)]
            self.master_data.loc[self.master_data['Field'].isin(week_rows), 'Data'] = np.array(week_data)
        else:
            week_rows = [f'Target_Week{week:02}_Baseline' for week in range(1,54)]
            self.master_data.loc[self.master_data['Field'].isin(week_rows), 'Data'] = 0


    def fill_meta(self, meta_series):
        for i in meta_series.index:
            if i in self.master_data['Field'].unique():
                self.master_data.loc[self.master_data['Field']==i, 'Data'] = meta_series[i]

    def save(self, save_path):
        self.master_data.to_csv(save_path, index=False)
        






