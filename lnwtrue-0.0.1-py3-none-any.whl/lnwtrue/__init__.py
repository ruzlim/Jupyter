from lnwtrue import mooc
from lnwtrue import score
from lnwtrue import trueconnect
# import lnwtrue.mooc

