

class MoocArea:
	import nzpy

	mooc_query = f"""
	SELECT *
	FROM CORPNAPPO.DIM_MOOC_AREA
	"""
# query_str = f"""
# SELECT *
# FROM CORPNAPPO.dim_mooc_area_bk20210409
# """

	def __init__(self):
		conn = nzpy.connect(
			user="CORP_CENT", 
			password="password",
			host='10.50.78.21', 
			port=5480, database="TDADEVBAE", 
			securityLevel=1,
			logLevel=0
			)

		self.mooc_area = pd.read_sql(mooc_query, conn)

