from calendar import monthrange, isleap
import datetime
import numpy as np

def get_month_in_week_number(year):
    month_in_week_number = []
    for week in range(0,54):
        input_date = f'{year}-W{week}'
        first_day_of_week = datetime.datetime.strptime(input_date + '-1', '%G-W%V-%u')
        last_day_of_week = first_day_of_week + datetime.timedelta(days=6)
        if first_day_of_week.month == last_day_of_week.month:
            month_days = [[first_day_of_week.month, 7]]
        else:
            month_days = [[first_day_of_week.month, monthrange(int(year), first_day_of_week.month)[1] - first_day_of_week.day + 1],
                  [last_day_of_week.month, last_day_of_week.day]]
        month_in_week_number.append(month_days)

    # remove Dec last year
    if len(month_in_week_number[0]) == 1 and month_in_week_number[0][0][0] == 12:
        month_in_week_number = month_in_week_number[1:]
        
    # remove Dec in Jan
    if month_in_week_number[0][0][0] == 12:
        month_in_week_number[0] = [month_in_week_number[0][1]]
        
    # remove next Jan
    if month_in_week_number[-1][0][0] == 1:
        month_in_week_number = month_in_week_number[:-1]
        
    # remove Next Jan in Dec
    if len(month_in_week_number[-1]) == 2:
        month_in_week_number[-1] = month_in_week_number[-1][:1]
    
    # merge week if not leap year and not 52
    if (not isleap(int(year))) and (len(month_in_week_number) == 53):
        month_in_week_number[1][0][1] += month_in_week_number[0][0][1]
        month_in_week_number = month_in_week_number[1:]
    
    return month_in_week_number

def accum(rows):
    last = 0
    output = []
    for row in rows:
        current = row+last
        last = current
        output.append(current)
    return output

def find_increase(scores, baseline):
    output = [scores[0] - baseline]
    for s in scores[1:]:
        output.append(s-output[-1])
        
    return np.array(output)

class MonthlyScore:

    def __init__(self, monthly_scores, is_accum=False, baseline=0, year=datetime.datetime.now().year):
        self.monthly_scores = np.array(monthly_scores)
        self.year = year
        self.total_weeks = len(get_month_in_week_number(self.year))
        self.baseline = baseline
        
        if is_accum:
            if self.baseline==0:
                self.baseline = self.monthly_scores[0] - ((self.monthly_scores[1] - self.monthly_scores[0])/2)
            
            self.weekly_scores = self._weekly_scores_accum()
            self.quarterly_scores = self._quarterly_scores_accum()
            self.annual_score = self.monthly_scores[-1]
            
            self.weekly_scores_accum = self.weekly_scores
            self.monthly_scores_accum = self.monthly_scores
            self.quarterly_scores_accum = self.quarterly_scores
            
            self.weekly_scores_increase = find_increase(self.weekly_scores_accum, self.baseline)
            self.monthly_scores_increase = find_increase(self.monthly_scores_accum, self.baseline)
            self.quarterly_scores_increase = find_increase(self.quarterly_scores_accum, self.baseline)
            
        else:
            self.weekly_scores = self._weekly_scores()
            self.quarterly_scores = self._quarterly_scores()
            self.annual_score = self.monthly_scores.sum()
            
            self.weekly_scores_accum = accum(self.weekly_scores)
            self.monthly_scores_accum = accum(self.monthly_scores)
            self.quarterly_scores_accum = accum(self.quarterly_scores)
            
            self.weekly_scores_increase = self.weekly_scores
            self.monthly_scores_increase = self.monthly_scores
            self.quarterly_scores_increase = self.quarterly_scores
            
        
    def _get_daily_score_from_monthly(self):
        daily_scores = []
        for i, score in enumerate(self.monthly_scores):
            days = monthrange(self.year, i+1)[1]
            daily_score = score / days
            daily_scores.append(daily_score)
        return daily_scores
        
    def _weekly_scores(self):
        daily_scores = self._get_daily_score_from_monthly()
        month_in_week_number = get_month_in_week_number(self.year)
        week_scores = []
        for row in month_in_week_number:
            week_score = 0
            for month_no, day_count in row:
                week_score += (daily_scores[month_no-1] * day_count)
            week_scores.append(week_score)
        return np.array(week_scores)
    
    def _quarterly_scores(self):
        # accum_month = accum(self.monthly_scores)
        # quarterly_scores = [accum_month[2], accum_month[5], accum_month[8], accum_month[11]]
        quarterly_scores = [sum(self.monthly_scores[:3]), sum(self.monthly_scores[3:6]), sum(self.monthly_scores[6:9]), sum(self.monthly_scores[9:])]
        return np.array(quarterly_scores)
    
    def _weekly_scores_accum(self):
        
        year_increase = self.monthly_scores[-1] - self.baseline
        week_increase = year_increase / self.total_weeks
        week_scores = [self.baseline + (week_increase*week) for week in range(1, self.total_weeks+1)]
        
        return np.array(week_scores)
    
    def _quarterly_scores_accum(self):
        quarterly_scores = [self.monthly_scores[2], self.monthly_scores[5], self.monthly_scores[8], self.monthly_scores[11]]
        return np.array(quarterly_scores)